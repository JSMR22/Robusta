
public class Main {

	public static void main(String[] args) throws DivisionCero {
		// TODO Auto-generated method stub
		//Operacion op=new Operacion();
		try {
			Operacion o=new Operacion();
			System.out.println(o.division(10, 0));

		}catch(Exception e)
		{
			System.out.println(e);
			
		}
		finally {
			Operacion o=new Operacion();
			/*try {
			o.division(10,1);
			}catch(Exception e)
			{
				
			}*/
		}
	}

}
