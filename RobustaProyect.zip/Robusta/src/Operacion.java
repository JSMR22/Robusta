
public class Operacion{
	public double division(double dividendo,double divisor) throws DivisionCero 
	{
		if(divisor==0)
		{
			throw new DivisionCero();
		}
		return dividendo/divisor;
	}

}
