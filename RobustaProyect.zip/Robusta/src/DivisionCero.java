
public class DivisionCero extends Exception {

}
